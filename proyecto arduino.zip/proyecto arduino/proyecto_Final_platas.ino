#include <DHT.h>
#include "HX711.h"
#include <WiFiS3.h>
#include <ArduinoHttpClient.h>
#include "arduino_secrets.h"

char ssid[] = SECRET_SSID;
char pass[] = SECRET_PASS;

// --- CONFIGURACIÓN DE TU SERVIDOR LARAVEL ---
char serverAddress[] = "192.168.1.11"; // ¡VERIFICA QUE ESTA SIGA SIENDO TU IP!
int port = 8000;
String apiPath = "/api/arduino/data";

WiFiClient wifi;
HttpClient client = HttpClient(wifi, serverAddress, port);

#define Type DHT22
int dhtPin = 2;
DHT HT(dhtPin, Type);

const float UMBRAL_TEMPERATURA = 45.0;
const int pinSensorHumedad = A0;
const int pinMotor = 10;
const int umbralHumedad = 45;

int valorSensor = 0;
int porcentajeHumedad = 0;
bool alertaTermica = false;

const int LOADCELL_DOUT_PIN = 6;
const int LOADCELL_SCK_PIN  = 5;
HX711 scale;
const float FACTOR_CALIBRACION = -209.9429;
const float UMBRAL_PESO_BAJO = 25.0; 

float tempActual = 0;
float pesoActual = 0;
bool bombaEncendida = false;
bool alertaPeso = false;
bool bombaManualWeb = false; 

// Temporizador para no saturar el servidor
unsigned long ultimoEnvio = 0;
const unsigned long INTERVALO_ENVIO = 3000; // Enviar datos cada 3 segundos

void setup() {
  Serial.begin(115200); // Subimos la velocidad del monitor serie a 115200
  // ¡IMPORTANTE! Cambia el monitor serie de tu IDE de Arduino a 115200 baudios
  
  Serial.print("Conectando a WiFi: ");
  while (WiFi.status() != WL_CONNECTED) {
    WiFi.begin(ssid, pass);
    delay(3000);
    Serial.print(".");
  }
  Serial.println("\n¡Conectado a WiFi!");

  HT.begin();
  pinMode(pinMotor, OUTPUT);
  digitalWrite(pinMotor, HIGH); // Iniciar apagado (por tu relé invertido)

  scale.begin(LOADCELL_DOUT_PIN, LOADCELL_SCK_PIN);
  delay(1000);
  scale.set_scale(FACTOR_CALIBRACION);
  delay(1000);
  scale.tare();
}

void loop() {
  // 1. Consultar la web SIEMPRE (para que el botón responda rápido)
  consultarBombaWeb();
  delay(200); // Pequeña pausa para que el servidor respire entre peticiones

  // 2. Leer sensores (esto es rápido, se hace siempre)
  tempActual = HT.readTemperature();
  if (!isnan(tempActual)) {
    alertaTermica = (tempActual >= UMBRAL_TEMPERATURA);
  }

  valorSensor = analogRead(pinSensorHumedad);
  // MAP CORREGIDO para tu sensor
  porcentajeHumedad = map(valorSensor, 1023, 0, 0, 100); 
  porcentajeHumedad = constrain(porcentajeHumedad, 0, 100);

  if (scale.is_ready()) {
    pesoActual = abs(scale.get_units(10));
    if (pesoActual < 1.0) pesoActual = 0;
    alertaPeso = (pesoActual < UMBRAL_PESO_BAJO);
  }

  // 3. Controlar la bomba
  controlBomba();

  // 4. Enviar datos a Laravel SOLO cada 3 segundos (usando el temporizador)
  if (millis() - ultimoEnvio >= INTERVALO_ENVIO) {
    ultimoEnvio = millis();
    enviarDatos();
  }
}

void controlBomba() {
  // PRIORIDAD 1: CONTROL MANUAL DESDE LA WEB
  if (bombaManualWeb) {
    digitalWrite(pinMotor, LOW); 
    bombaEncendida = true;
  } 
  // PRIORIDAD 2: ALERTA TÉRMICA
  else if (alertaTermica) {
    digitalWrite(pinMotor, LOW); 
    bombaEncendida = true;
  } 
  // PRIORIDAD 3: AUTOMÁTICO POR HUMEDAD
  else {
    if (porcentajeHumedad > umbralHumedad) {
      digitalWrite(pinMotor, HIGH); 
      bombaEncendida = false; 
    } else {
      digitalWrite(pinMotor, LOW); 
      bombaEncendida = true;
    }
  }
}

void consultarBombaWeb() {
  if (WiFi.status() == WL_CONNECTED) {
    client.get("/api/arduino/bomba-estado");
    
    int statusCode = client.responseStatusCode();
    if (statusCode == 200) {
      String response = client.responseBody();
      if (response.indexOf("1") > 0 || response.indexOf("true") > 0) {
        bombaManualWeb = true;
      } else {
        bombaManualWeb = false;
      }
    }
    client.stop(); 
  }
}

void enviarDatos() {
  if (WiFi.status() == WL_CONNECTED) {
    String postData = "{";
    postData += "\"temperatura\": " + String(tempActual) + ",";
    postData += "\"humedad\": " + String(porcentajeHumedad) + ",";
    postData += "\"peso\": " + String(pesoActual) + ",";
    postData += "\"alerta_termica\": " + String(alertaTermica ? "true" : "false") + ",";
    postData += "\"bomba_encendida\": " + String(bombaEncendida ? "true" : "false") + ",";
    postData += "\"alerta_peso\": " + String(alertaPeso ? "true" : "false");
    postData += "}";

    client.beginRequest();
    client.post(apiPath);
    client.sendHeader("Content-Type", "application/json");
    client.sendHeader("Content-Length", postData.length());
    client.beginBody();
    client.print(postData);
    client.endRequest();

    int statusCode = client.responseStatusCode();
    
    // Imprimimos en el monitor serie para ver qué pasa
    Serial.print("Datos enviados. HTTP: ");
    Serial.println(statusCode);
    
    client.stop();
  }
}